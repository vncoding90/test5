var app = angular.module('angularjs-starter', ['dotjem.angular.tree']);

app.controller('MainCtrl', ['$scope', function($scope) {
  $scope.list = {
    "id": "0",
    "name": "foo",
    "items": [
        {
            "id": "0100",
            "name": "bar",
            "items": [
                {
                    "id": "0101",
                    "name": "baz"
                },
                {
                    "id": "0102",
                    "name": "qux",
                    "items": [
                        {
                            "id": "010201",
                            "name": "xyzzy"
                        }
                    ]
                }
            ]
        }
    ]
  }
}])
.directive('tree', ['$compile', '$log', function ($compile, $log) {
  return {
    restrict: 'E',
    terminal: true,
    scope: { val: '=', parentData:'=' },
    templateUrl: 'template.html',
    link: function (scope, element, attrs) {
      
    }
  };
}]);