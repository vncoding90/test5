var app = angular.module('angularjs-starter', []);

app.controller('MainCtrl', ['$scope', function($scope) {
  $scope.list = {
    "id": "0",
    "name": "foo",
    "items": [
        {
            "id": "0100",
            "name": "bar",
            "items": [
                {
                    "id": "0101",
                    "name": "baz"
                },
                {
                    "id": "0102",
                    "name": "qux",
                    "items": [
                        {
                            "id": "010201",
                            "name": "xyzzy"
                        }
                    ]
                }
            ]
        }
    ]
  }
}])
.directive('tree', ['$compile', '$log', function ($compile, $log) {
  return {
    restrict: 'E',
    terminal: true,
    scope: { val: '=', parentData:'=' },
    link: function (scope, element, attrs) {
      scope.checked = [];
      scope.$watch('val', function (val, oldVal) {
        if (val) {
          val.show = true;
          var template = '<input type="checkbox"><a href="" ng-click="val.show = !val.show">{{val.name + " +"}}</a>';
          if (angular.isArray(scope.val.items)) {
            template += '<ul ng-show="val.show" class="indent"><li ng-repeat="item in val.items"><tree val="item" parent-data="val.items"></tree></li></ul>';
          }
          var newElement = angular.element(template);
          $compile(newElement)(scope);
          element.replaceWith(newElement);
        }
      });
    }
  };
}]);